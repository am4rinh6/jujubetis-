function setup() {
  createCanvas(100, 100);

  background(200);

  // Give each corner a unique radius.
  rect(30, 20, 55, 50, 20, 15, 10, 5);

  describe('A white rectangle with a black outline and round edges of different radii.');
}