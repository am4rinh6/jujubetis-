function setup() {
  createCanvas(100, 100);

  background(200);

  arc(50, 50, 80, 40, 0, PI + HALF_PI);

  describe('A white ellipse on a gray canvas. The top-right quarter of the ellipse is missing.');
}